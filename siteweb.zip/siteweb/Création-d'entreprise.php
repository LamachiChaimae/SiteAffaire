<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <style> <?php include 'css/style.php' ?> </style>
    <title>Document</title>
</head>
<body>
 <?php include 'Header.php' ?>
 <hr/>
 <div class="creation">
 <h1 class="h1D">Création D’entreprise au Maroc</h1><br><br>
 <img src="images/entrprse1.jpg" alt="" class="imgD" />
 <h2 class="h2D">
     POUR POUVOIR ENTAMER LA PROCÉDURE DE CRÉATION D’ENTREPRISE AU MAROC NOUS AVONS BESOIN DES ÉLÉMENTS SUIVANTS:
 </h2>
 <br><br>
   <p class="P1">
        <p>  1 . Vos Choix de dénominations Sociales (de préférence deux choix par</p>
        <p>2 . La forme juridique de votre choix</p>
        <p>3 . La ou les copie(s) de(s) Carte(s) Nationale (pour les Marocains), la Carte de séjour (pour les résidents étrangers) et le passeport (pour les étrangers non Résidents) des associés et des Gérants.
        </p>
        <p>4 . L’objet social (l’activité) de l’entreprise</p>
        <p>5 . l’adresse (soit un certificat de Propriété, contrat de bail ou bien une Domiciliation dans nos Locaux)</p>
        <p>6 . la répartition des parts sociales entre les associés</p>
        <p>7 . le capital a mentionner sur les statuts</p>
        <p>8 . La gérance (un ou plusieurs Gérants est possible)</p>
        <h3 class="h2D">Durée de la procédure de création d’entreprise :</h3>
        <p>
            la durée dépend de la ville de Domiciliation , mais généralement une
            fois les documents remis par le client a l’agence de son choix une
            création simple sur une ville comme casablanca prends 8 jours ouvrables
            (notez que ce délai ne prend pas en compte les périodes de Grèves des
            administrations concernées par les procédures de création d’entreprise
            ni les pannes de systemes qui peuvent les impacter)
        </p>
   </p>
   <br><br><br><br><br><br><br>
   <div class="juridique">
        <p>
          Notez bien que Machrouhi Affaire prend en charge toute la procédure de
          création et de Domiciliation de votre entreprise même si vous
          n’habitez pas dans la ville ou vous aurez choisi de la domicilier.
        </p>
        <h3>Autres services :</h3>
        <p>
          Machrouhi Affaire vous propose aussi selon les packs sélectionnés tous
          les outils nécessaires à votre activité.
        </p>
        <p>
          Carte de visite, cachet d’entreprise, logo d’entreprise, site web ...
        </p>
        <p>
          Et tout ça avec des prix compétitifs et parmi les meilleurs tarifs du
          marché !
        </p>
        <p>
          Nous sommes votre centre d’affaires de confiance et nous vous
          souhaitons la bienvenue chez Machrouhi Affaire .
        </p>
    </div>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br>

    <div class="offre">
      <div class="titre">
        <h2>Offres spéciales</h2>
        <h4>PACK BASIC</h4>
        <h6>-35% de remise</h6>
        <h5>2000 DH</h5>
      </div>
      <ul>
        <li>* Certificat négatif (nom de l’entreprise)</li>
        <li>* Enregistrement des statuts</li>
        <li>* Registre du commerce Modèle 4</li>
        <li>* Registre du commerce Modèle J</li>
        <li>* Annonce légale ( journal)</li>
        <li>* D'identification DE LA TAXE PROFESSIONNELLE</li>
        <li>* D'identification fiscale</li>
        <li>* S'inscrire à la sécurité sociale ( CNSS )</li>
      </ul>    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

      <div class="titre">
        <h4>PACK START</h4>
        <h6>-35% de remise</h6>
        <h5>3500 DH</h5>
      </div>
      <ul>
        <li>* Certificat négatif (nom de l’entreprise)</li>
        <li>* Une adresse fiscale pour le siège de votre entreprise, ainsi qu’une gestion efficace de votre courrier</li>
        <li>* Domiciliation 12 Mois Renouvelable</li>
        <li>* Enregistrement des statuts</li>
        <li>* Registre du commerce Modèle 4</li>
        <li>* Registre du commerce Modèle J</li>
        <li>* Annonce légale ( journal)</li>
        <li>* D'identification DE LA TAXE PROFESSIONNELLE</li>
        <li>* D'identification fiscale</li>
      </ul>
      <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
      <div class="titre">
        <h4>PACK PRO</h4>
        <h6>-35% de remise</h6>
        <h5>5000 Dh</h5>
      </div>
      <ul>
        <li>* Certificat négatif (nom de l’entreprise)</li>
        <li>* Une adresse fiscale pour le siège de votre entreprise, ainsi qu’unegestion efficace de votre courrier</li>
        <li>* Domiciliation 6 Plus 6 Mois Gratuit</li>
        <li>* Enregistrement des statuts</li>
        <li>* Registre du commerce Modèle 4</li>
        <li>* Registre du commerce Modèle J</li>
        <li>* Annonce légale ( journal)</li>
        <li>* D'identification DE LA TAXE PROFESSIONNELLE</li>
        <li>* D'identification fiscale</li>
        <li>* Scan Et Envoie De Votre Courrier Par Mail (Avec Autorisation) (12 Mois)</li>
        <li>* Notification par mail ou SMS lors de la réception du courrier (12 Mois)</li>
        <li>* Cachet de la société Gratuitement</li>
        <li>* Petit site professionnel pour présenter sa société</li>
        <li>* Hébergement, 10Go D'espace Web</li>
        <li>* Design Personnalisé Professionnel</li>
        <li>* Trois page</li>
        <li>* Nom De Domaine Gratuit Inclus (12 Mois)</li>
        <li>* 2 Adresses E-Mail Pro (Nom@Votreentreprise.Com )</li>
        <li>* Maintenance</li>
      </ul><br/><br/><br/><br/><br/><br/><br/><br/><br/>
   </div>
</div>
<br/><br/> <br/><br/><br/> <br/><br/><br/> <br/><br/><br/> <br/><br/><br/> <br/><br/><br/> <br/><br/><br/> <br/>
    <br/><br/> <br/><br/><br/> <br/><br/><br/> <br/><br/><br/> <br/><br/><br/> <br/><br/><br/> <br/><br/><br/> <br/>
    <br/><br/> 

<?php include 'Footer.php' ?>

 
 

</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">

</head>
<body>
    <?php include 'Header.php'?><br/><br/><br/>
    <div class="credit">
    <h1 class="h1D">La Crédit ; Initiative</h1><br><br>
    <div class="imagecre">
     <img src="images/téléchargement.jpg" alt="" class="imagecredit"><br>
     <img src="images/WhatsApp Image 2022-01-23 at 16.58.23 (1).jpeg" alt="" class="imagecredit"><br>
     <img src="images/WhatsApp Image 2022-01-23 at 16.58.21 (1).jpeg" alt=""class="imagecredit"><br>
     <img src="images/WhatsApp Image 2022-01-23 at 16.58.21.jpeg" alt=""class="imagecredit peti"><br>
     <img src="images/WhatsApp Image 2022-01-23 at 16.58.22 (1).jpeg" alt=""class="imagecredit"><br>
     <img src="images/WhatsApp Image 2022-01-23 at 16.58.22.jpeg" alt=""class="imagecredit"><br>
     <img src="images/WhatsApp Image 2022-01-23 at 16.58.20 (1).jpeg" alt=""class="imagecredit"><br>
     <img src="images/WhatsApp Image 2022-01-23 at 16.58.20.jpeg" alt=""class="imagecredit"><br>
    </div>

    </div>
    <?php include 'Footer.php' ?>

</body>
</html>
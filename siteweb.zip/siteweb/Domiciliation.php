<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>  <?php include 'css/style.php' ?> </style>
    <title>Document</title>
</head>
<body>
    <?php include 'Header.php' ?>
    <hr/>
    <div class="domicile">
        <h1 class="h1D">La Domiciliation</h1><br><br>
        <img src="images/domiciliation.jpeg" class="imgD">
        <h2 class="h2D">
            Une Adresse Prestigieuse Pour Votre Entreprise À Partir De 100 TTC DHs /
            Mois Le Siège Social De Votre Entreprise Au Meilleur Prix Au Maroc
        </h2>
        <p>
            Machrouhi Affaire est une société qui offre des solutions et des
            prestations innovantes dans le secteur de la domiciliation entreprise
            Marocain. Nous avons développé des produits spécifiques afin de
            permettre aux entrepreneurs marocain et étrangers de démarrer rapidement
            leur activité en toute sécurité et dans les meilleures conditions
            possibles. Vous disposez dès le départ et selon votre pack d’une
            domiciliation commerciale , d’une adresse, d’une secrétaire qui gère vos
            appels et votre courrier, des bureaux partagés avec tout le matériel
            nécessaire pour vos présentations et vos rencontres d’affaires. CS+ vous
            propose aussi selon les packs sélectionnés tous les outils nécessaires à
            votre activité. Carte de visite, cachet d’entreprise, logo d’entreprise,
            site web one page. Et tout ça avec des prix compétitifs et parmi les
            meilleurs tarifs du marché ! Nous sommes votre centre d’affaires de
            confiance et nous vous souhaitons la bienvenue chez CS Plus. Procédures:
            Grâce à sa présence nationale et internationale, le groupe maure offre à
            ces clients un grand choix d'adresses de domiciliation d'entreprise au
            maroc à casablanca, rabat, tanger, et Beni Mellal. les documents
            nécessaires pour la domiciliation d’entreprise au maroc: 1-La ou les
            copie (s) de (s) Carte (s) Nationale (pour les Marocains), la Carte de
            séjour (pour les résidents étrangers) et le passeport (pour les
            étrangers non Résidents) des associés et des Gérants 2-le certificat
            négatif (si vous ne l’avez pas sur l’obtention pour vous) Durée de la
            procédure de domiciliation d’entreprise: la procédure une fois
            l’engagement de Domiciliation signé par le client ne prend généralement
            pas plus de 24 heures.
        </p><br><br><br><br><br>
    </div>
    <div class="offre">
       <div class="titre">
            <h2>Offres spéciales</h2>
            <h4>PACK BASIC</h4>
            <h6>-35% de remise</h6>
            <h5>104 DH / TTC Par Mois</h5>
      </div>
      <ul>
        <li>* Adresses Administratives</li>
        <li>* Domiciliation Juridique, Fiscale</li>
        <li>* Réception du Courrier</li>
        <li>* Notification par Mail ou SMS Lors de la Réception du Courrier</li>
      </ul>
      <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
      <div class="titre">
        <h4>PACK START</h4>
        <h6>-40% de remise</h6>
        <h5>150 DH / TTC Par Mois</h5>
      </div>
      <ul>
        <li>* Adresses Administratives</li>
        <li>* Domiciliation Juridique, Fiscale et Commerciale de Votre Siège Social</li>
        <li>* Réception du Courrier * Notification par Mail ou SMS Lors de la Réception du Courrier</li>
        <li>* Scan Et Envoie De Votre Courrier Par Mail (Avec Autorisation)</li>
      </ul>
      <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>

      <div class="titre">
        <h4>PACK PRO</h4>
        <h6>-43% de remise</h6>
        <h5>200 DH / TTC Par Mois</h5>
      </div>
      <div class="clearfix"></div>
      <ul>
        <li><span class="SPD">*Domiciliation Juridique, Fiscale et Commerciale de Votre Siège Social</span></li>
        <li>* Contrat de Domiciliation</li>
        <li>* Attestation De Domiciliation</li>
        <li>* Adresses Administratives</li>
        <li>* Réception du Courrier</li>
        <li>* Notification par Mail ou SMS Lors de la Réception du Courrier</li>
        <li>* Scan Et Envoie De Votre Courrier Par Mail (Avec Autorisation)</li>
        <li><span class="SPD">* Petit site professionnel pour présenter sa société</span></li>
        <li>* Hébergement, 10Go D'espace Web</li>
        <li>* Design Personnalisé Professionnel</li>
        <li>* Trois page</li>
        <li>* Nom De Domaine Gratuit Inclus (12 Mois)</li>
        <li>* 2 Adresses E-Mail Pro <span class="SPD1">(Nom@Votreentreprise.Com )</span></li>
        <li>* Maintenance</li>
      </ul><br/><br/><br/><br/><br/><br/><br/><br/><br/>
    </div>
<!--     <div class="clearfix"></div>
 -->    <br/><br/> <br/><br/><br/> <br/><br/><br/> <br/><br/><br/> <br/><br/><br/> <br/><br/><br/> <br/><br/><br/> <br/>
    <br/><br/> <br/><br/><br/> <br/><br/><br/> <br/><br/>

  <?php include 'Footer.php' ?>

</body>
</html>
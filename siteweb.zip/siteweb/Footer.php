<footer class="footer2">
      <div class="row">
        <div class="clearfix"></div>
        <div class="clearfix"></div>
        
        <div class="col">
          <p>Expert business solutions</p>
        </div>
        <div class="col">
          <h3>Ofiice  <div class="underline"><span></span></h3>
          <p>Mr Machrouhi Rabie</p>
          <h4>06 12 62 62 61 - 06 69 43 33 33</h4>
        </div>
        <div class="col">
          <h3>Links<div class="underline"><span></span></h3>
            <ul>
              <li><a href="">Home</a></li>
              <li><a href="">Services</a></li>
              <li><a href="">Features</a></li>
              <li><a href="">Contacts</a></li>
            </ul>
        </div>
        <div class="col">
          <h3>Newsletter<div class="underline"><span></span></h3>
            <form>
              <i class="fas fa-envelope"></i>
              <input type="email-id" placeholder="Enter your email" required>
              <button type="submit"><i class="fas fa-arrow-right"></i></button>
            </form>
            <div class="social-icons">
              <i class="fab fa-facebook"></i>
              <i class="fab fa-twitter"></i>
              <i class="fab fa-whatsapp"></i>
            </div>
        </div>
      </div>
      <hr>
      <p class="copyright">Centre Affaire&copy;2021 -All Rights Reserved</p>
</footer>

<?php 
   include('config/constants.php');
?>

<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
         <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/>
         <script src="https://kit.fontawesome.com/51f7ea6787.js" crossorigin="anonymous"></script>
         <script src="https://kit.fontawesome.com/c4254e24a8.js" crossorigin="anonymous"></script>
         <script type="text/javascript" src="js/script.js" defer="defer"></script>
        <title>Document</title>
        <style>
            <?php include 'css/style.css'?>
        </style>
    </head>
    <body>
    <header>   
    <nav class="navbar"> 
      <div class="navbar__container">
        <a href="#" class="logo" id="navbar__logo"><span class="SP">C</span>ENTRE <span class="SP">A</span>FFAIRE</a>
         <div class="navbar__toggle" id="mobile-menu">
             <span class="bar"></span>
             <span class="bar"></span>
             <span class="bar"></span>
         </div> 
      <ul class="navbar__menu">
          <li class="navbar__item">
              <a href="<?php echo SITEURL; ?>" class="navbar__Links">Accuil</a>
           </li>
           <li class="navbar__item">
              <a href="<?php echo SITEURL; ?>Domiciliation.php" class="navbar__Links">Domiciliation</a>
           </li>
           <li class="navbar__item">
              <a href="<?php echo SITEURL; ?>Création-d'entreprise.php" class="navbar__Links">Création d'entreprise</a>
           </li>
           <li class="navbar__item">
              <a href="<?php echo SITEURL; ?>Juridique.php" class="navbar__Links">Comptabilité/Juridique</a>
           </li>
           <li class="navbar__item">
              <a href="<?php echo SITEURL; ?>Crédit.php" class="navbar__Links">Crédit Bancaires</a>
           </li>
           <li class="navbar__item"> 
               <a href="Publicité.php" class="navbar__Links">Pulicité</a>
            </li>
          <!--  <li class="navbar__item">
              <a href="/" class="navbar__Links">Contacts</a>
           </li> -->
      </ul>
    </nav>
 </div>
</header>
<div class="affaire">
       <img src="images/machrouhi.jpg" class="img">     

    </div>
    <div class="container">
       <h2></h2>
       <?php
            //create sql query to display 
            $sql = "SELECT * FROM tbl_category WHERE active='Yes' AND featured='Yes' LIMIT 2";

            $res = mysqli_query($conn, $sql);
            $count = mysqli_num_rows($res);
            if($count>0)
            {
               while($row = mysqli_fetch_array($res))
               {
                  $id = $row['id'];
                  $image_name = $row['image_name'];
                  ?>
                   <div class="box3 float-container">
                      <?php
                        if($image_name=="")
                        {
                           //display message
                           echo "<div class='error'>image not avaible</div>";
                        }
                        else
                        {
                           ?>
                              <img src="<?php echo SITEURL; ?>images/category/<?php echo $image_name; ?>" class="img-responsive img-curve">
                           <?php
                        }
                      ?>
                   </div>
                  <?php
               }
            }
            else
            {
               echo "<div class='error'>Category not Added.</div>";
            }
       ?>



    </div>

    <div class="machrouhi"><br/>
      <h1>Machrouhi Affaire</h1>
      <h4>est toujours à votre disposition</h4><br/>
     </div>
      <div class="icons">
        <i
          class="fa fa-facebook-square"
          style="font-size: 35px; color: rgb(30, 162, 196)"
        ></i>
        <i
          class="fa fa-google-plus-square"
          style="font-size: 35px; color: rgb(30, 162, 196)"
        ></i>
        <i
          class="fa fa-linkedin-square"
          style="font-size: 35px; color: rgb(30, 162, 196)"
        ></i>
        <i class="fa fa-whatsapp" style="font-size: 35px; color: rgb(30, 162, 196)"></i>
        <i
          class="fa fa-youtube-square"
          style="font-size: 35px; color: rgb(30, 162, 196)"
        ></i>
      </div>
      <br/><br/>
        
    </body>
    </html>

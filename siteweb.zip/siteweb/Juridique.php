<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style> <?php include 'css/style.php' ?> </style>
    <title>Document</title>
</head>
<body>
<?php include 'Header.php' ?>
<hr/>
<div class="juridique">
    <h1 class="h1D">Comptabilité/Juridique</h1><br><br>
    <img src="images/pexels-nataliya-vaitkevich.jpg" alt="" class="imgD" /> &ensp; &ensp; &ensp; 
    <h2 class="h2D"> Comptabilité Déclaration fiscale (TVA ; CNSS ; IR ; IS).... à partir de 200Dh /3 mois</h2><br><br>
    <p>
        Toute entreprise doit avoir une comptabilité juste et sincère. Cela
        intéresse les services fiscaux, les actionnaires et les banquiers qui
        souhaitent évaluer l’état de santé des entreprises. Chaque année,
        l’expert-comptable vérifie la régularité des comptes des entreprises
        qu’il a en charge. Il établit ou fiabilise la comptabilité de ses
        clients (artisans, commerçants, professions libérales, petites ou
        grandes entreprises, associations). Il les conseille également sur leur
        développement économique, leur fiscalité, les systèmes de gestion
        informatisés adaptés. Chaque année, il arrête les bilans financiers de
        ses clients mais ses missions peuvent varier selon les entreprises :
        taille et type d’activité notamment. Aimer analyser les chiffres et être
        rigoureux ne suffit pas. Le relationnel est au cœur du métier. En effet,
        l’expert-comptable est souvent le conseiller privilégié du chef
        d’entreprise en matière de gestion, de fiscalité, d’organisation, de
        droit social. C’est un professionnel de contact qui exerce à titre
        libéral, en cabinet d’expertise ou avec des associés. On le rencontre
        également en entreprise sur des postes de cadre financier.
    </p>
    <br><br>
    <h3 class="h2D">Comptabilité d'entreprise "Services En Ligne":</h3><br>
      <p>
        Conseil et Audit : Déclaration de TVA , Bilan , Etats divers, AGO, tenue
        de comptes et conseil etc...
      </p>
      <div class="juridique1">
        <h3 class="h2D">Juridique:</h3><br />
        <p>
          Amendements : Transfert de siège social, Nomination de Gérant, Cession
          de parts, Extension d'objet social etc...
        </p>
        <h3 class="h2D">Le Service « ATTESTATION » "Services En Ligne":</h3>
        &ensp; &ensp; &ensp; <p>
          Les attestations mises en service sont : Attestation d'Inscription à
          la Taxe Professionnelle Demande Code d'accès et Validation DGI
        </p><br />
        <h2>Demande RC en linge:</h2><br />
        <ul>
          <li>¤ Demande d’attestation de régularité fiscale</li>
          <li>¤ Bulletin d’Identification Fiscale</li>
          <li>¤ Attestation de Chiffre d’affaires</li>
          <li>¤ Attestation du chiffre d'affaires réalisé à l'exportation</li>
          <li>¤ Attestation de Revenu</li>
          <li>¤ Attestation de non déductibilité des cotisations d’assurance retraite complémentaire</li>
          <li>¤ Attestation d'imposition forfaitaire</li>
          <li>¤ Attestation de Résidence Fiscale (Certificate of residence)</li>
          <li>¤ Attestation d’achat en exonération, en suspension de la TVA ou au taux réduit de 7%</li>
          <li>¤ Suivi des dépôts de demandes d’attestations d’achat en exonération, en suspension de la TVA ou au taux réduit de 7%</li>
          <li>¤ Attestation de retenue à la source</li>
          <li>¤ Attestation de Radiation de la Taxe Professionnelle</li>
          <li>¤ Attestation d’exonération de la Taxe d’Habitation -Taxe de Services Communaux (TH/TSC)</li>
          <li>¤ Attestation d'Imposition à la Taxe d’Habitation -Taxe de Services Communaux</li>
          <li>¤ Attestation de Non-imposition à la Taxe d’Habitation - Taxe de Services Communaux</li>
          <li>¤ Attestation d’éligibilité de l’acquéreur à l’exonération de la TVA du logement social</li>
          <li>¤ Attestation de valeur locative</li>
          <li>¤ Attestation de paiement de la Taxe Spéciale Annuelle sur les Véhicules</li>
          <li>¤ Attestation d’exonération de la Taxe Spéciale Annuelle sur les Véhicules </li>
        </ul>&ensp; &ensp; &ensp; 

        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        <br><br><br>
        <h2>Recherche Entreprise "Services En Ligne"</h2><br><br>
        <p>
          Pour la sécurité des transactions commerciales, le service « Recherche entreprise » est accessible au public.
        </p>
        <p>
          Il œuvre pour la transparence et la sécurité des transactions entre entreprises,en permettant à toute personne.
        </p>
        <p>
          de s’assurer qu’une entreprise est bien identifiée auprès de Machrouhi Affaire et d’obtenir les renseignements.
        </p>
        <p> suivants,sur simple des numéro ICE, IF, raison sociale ou RC :</p>
        <ul Class="list">
          <li>¤ Dénomination</li>
          <li>¤ Statut juridique</li>
          <li>¤ Tribunal</li>
          <li>¤ N° de RC</li>
          <li>¤ N° de ICE</li>
          <li>¤ Identifiant fiscal</li>
          <li>¤ Activité</li>
          <li>¤ Forme juridique</li>
          <li>¤ Date d'immatriculation</li>
          <li>¤ Capital (en MAD)</li>
          <li>¤ L’adresse.</li><br/><br/><br/><br/><br/><br/>
        </ul><br/><br/><br/><br/><br/><br/><br/><br/><br/>
      </ul>
    </div>
    <br/><br/> <br/><br/><br/> <br/><br/><br/> <br/><br/><br/> <br/><br/><br/> <br/><br/><br/> <br/><br/><br/> <br/>
    <br/><br/> 
    <div class="clearfix"></div>

<?php include 'Footer.php' ?>

</div>
</body>
</html>
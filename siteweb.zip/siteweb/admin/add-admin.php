
<?php include 'partails/menu.php'?>
    <!-- Main content section starts -->
    <div class="main-content">
        <div class="wrapper">
            <h1>ADD ADMIN</h1>
            <br /><br />

            <?php 
                if(isset($_SESSION['add'])){ //Checking whether the session is set of not

                    echo $_SESSION['add']; //Display session Message if set
                    unset($_SESSION['add']); //Removing session Message 
                }
            ?>

            <form action="" method="post">

                <table class="tbl-30">
                    <tr>
                        <td>Nom Complet :</td>
                        <td><input type="text" name="full_name" placeholder="Entrez votre nom"></td>
                    </tr>
                    <tr>
                        <td>Nom d'Utilisateur :</td>
                        <td><input type="text" name="username" placeholder="saisissez votre nom d'utilisateur"></td>
                    </tr>
                    <tr>
                        <td>Mot de Passe :</td>
                        <td><input type="password" name="password" placeholder="Entrez mot de passe"></td>
                    </tr>
                    <tr>
                        <td colspan="2">
                         <input type="submit" name="submit" value="Add Admin" class="btn-secondry">
                        </td>
                    </tr>
                </table>
            </form>
        </div>
    </div>


     <!-- Main content section starts -->
     <div class="footer">
        <div class="wrapper">
            <div class="text-center">2022-All rights reserved</div>
        </div>
    </div>
    <!-- Main content section ends -->

    <?php 
        //Process the value from form and save it indatabase 
        //Check whether the submit buttom is clicked or not
        if(isset($_POST['submit'])){
            //1. Get the data from form
            $full_name = $_POST['full_name'];
            $username = $_POST['username'];
            $password =md5($_POST['password']);

            //2. SQL Query to save the Database
            $sql = "INSERT INTO tbl_admin SET full_name='$full_name' , username='$username' , password='$password'";

            //3. Execute Query and saving Data into Database
            $res = mysqli_query($conn, $sql) or die(mysqli_error());

            //4. Check whether (Query is executed) data is inserted not and display appropriate message 
            if($res==TRUE){
                //create a session variable to display message and
                $_SESSION['add'] = "Admin Added Successfully";
                //Redirect Page  to message Admin
                header("Location:".SITEURL.'admin/manage-admin.php');
            }
            else{
                $_SESSION['data'] = "Failed to Add Admin";
                //Redirect Page to Admin
                header('Location:'.SITEURL.'admin/add-admin.php');
            }

           
        }

    ?>
</body>
</html>
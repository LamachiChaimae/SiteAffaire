<?php include ('partails/menu.php');?>



    <div class="main-content">
        <div class="wrapper">
            <h1> Add Gategory</h1>

            <br/><br/>
            
            <?php 
               
                if(isset($_SESSION['add'])){
                    //Checking whether the session is set of not
                   echo $_SESSION['add']; //Display session Message if set
                   unset($_SESSION['add']); //Removing session Message 
               }
               if(isset($_SESSION['upload'])){
                //Checking whether the session is set of not
               echo $_SESSION['upload']; //Display session Message if set
               unset($_SESSION['upload']); //Removing session Message 
           }
            ?>
            <br/><br/>

            <!-- Add Category Form starts -->
            <form action="" method="POST" enctype="multipart/form-data">

                <table class="tbl-30">
                    <tr>
                        <td>Title :</td>
                        <td>
                            <input type="text" name="title" placeholder=" Category Title">
                        </td>
                    </tr>

                    <tr>
                        <td>Select Image :</td>
                        <td>
                            <input type="file" name="image">
                        </td>
                    </tr>

                    <tr>
                        <td>Featured :</td>
                        <td>
                            <input type="radio" name="featured" value="Yes"> Yes  
                            <input type="radio" name="featured" value="No"> No  
                        </td>
                    </tr>

                    <tr>
                        <td>Active :</td>
                        <td>
                            <input type="radio" name="active" value="Yes"> Yes
                            <input type="radio" name="active" value="No"> No
                        </td>
                    </tr>

                    <tr>
                        <td colspan="2">
                            <input type="submit" name="submit" value="Add Category" class="btn-secondary">
                        </td>
                    </tr>
                </table>
            </form>
            <!-- Add category form Ends-->


            <?php
                //Check whether ... 
                if(isset($_POST['submit']))
                {
                    //1. Cet the value from category form echo "clicked";
                    $title = $_POST['title'];
                    //For redio input , we need to check whether the button is selected or not
                    if(isset($_POST['featured']))
                    {
                        $featured = $_POST['featured'];
                    }else{
                        //Set the value default
                        $featured = "No";
                    }

                    if(isset($_POST['active']))
                    {
                        $active = $_POST['active'];
                    }
                    else{
                        //Set the value default
                        $active = "No";
                    }
                    //Check whether the value the image is celected or not
                //  print_r($_FILES['image']);                  
                    //die(); //break
 
                    if(isset($_FILES['image']['name'])){
                        //Upload image 
                        //we need image name , source path
                        $image_name =$_FILES['image']['name'];

                        //upload the image only if image is selected
                        if($image_name !="")
                        {

                            //Auto rename our image
                            //get the extension of or image (jpg ...)  "specailimaga1.jpg
                            $ext = end(explode('.',$image_name));

                            //rename the image
                            $image_name = "Image_Category_".rand(000, 999).'.'.$ext;

                            $source_path =$_FILES['image']['tmp_name'];
                            $destinatin_path = "../images/category/".$image_name;

                            //Finally
                            $upload = move_uploaded_file($source_path, $destinatin_path);
                            //check whether the image is upload or not
                            //And if the image is not uploaded then we will stop the process and redirect with error message
                            if($upload==false){
                                //Set message
                                $_SESSION['upload'] = "<div class='error'>Failed to upload image</div>";
                                //Redirct to category
                                header('Location:'.SITEURL.'admin/add-category.php');

                                die();
                            }
                        }
                    }
                    else{
                        $image_name = "";
                    }



                    //2. sql query insert category into database
                    $sql = "INSERT INTO tbl_category SET 
                            title='$title',
                            image_name='$image_name', 
                            featured='$featured', 
                            active='$active' 
                        ";

                    //3. Excute the query
                    $res = mysqli_query($conn, $sql);
                    
                    //4. check whether the query executed
                    if($res==true)
                    {
                        echo "hello";
                        //query executed
                        $_SESSION['add'] = "<div class='success'> Category Added successfully.</div>";
                        header('Location:'.SITEURL.'admin/manage-category.php');
                    }
                    else
                    {
                        $_SESSION['add'] = "<div class='error'> Failed to Add  Category .</div>";
                        header('Location:'.SITEURL.'admin/add-category.php');
                    }
                }
            
            ?>
        </div>
    </div>




<?php include ('partails/footer.php');?>



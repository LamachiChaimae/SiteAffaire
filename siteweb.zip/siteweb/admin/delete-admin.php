<?php
    include ('../config/constants.php');
    //1. get the id of admin to be deleted
    $id = $_GET['id'];
    //2. create sql query to database admin user
    $sql = "DELETE FROM tbl_admin WHERE id = $id";
    //Execute the query
    $res = mysqli_query($conn, $sql);
    //Check wheter the query executed successfully or not 
    if($res ==true){
        //create session variable to display message
        $_SESSION['delete']="<div class='success'>Admin Deleted Successfully .</div>"; 
        //Redirect to message Admin page
        header("Location:".SITEURL."admin/manage-admin.php");
    }else{
        $_SESSION['delete']="<div class='error'> Failed to  Deleted Admin try again later .</div>";
        header("Location:".SITEURL."admin/manage-admin.php");
    }
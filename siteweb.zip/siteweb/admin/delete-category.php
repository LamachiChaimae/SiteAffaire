<?php
    include('../config/constants.php');


        if(isset($_GET['id']) AND isset($_GET['image_name']))
        {
            //echo "Get value and delete";

            $id = $_GET['id'];
            $image_name = $_GET['image_name'];
            //remove the physical image_name
            if($image_name != "")
            {
                $path = "../images/category/".$image_name;
                //remove the image
                $remove = unlink($path);
                if($remove==false)
                {
                    $_SESSION['remove'] = "<div class='error'>Faile to remove category image.</div>";
                    header('Location:'.SITEURL.'admin/manage-category');
                    die();
                }

            }

            $sql = "DELETE FROM tbl_category WHERE id=$id";

            $res = mysqli_query($conn, $sql);

            if($res==true)
            {
                $_SESSION['delete'] = "<div class='success'> Category Deleted successfully.</div>";
                header('Location:'.SITEURL.'admin/manage-category');
            }else
            {
                $_SESSION['delete'] = "<div class='error'>Failed to Deleted Category .</div>";
                header('Location:'.SITEURL.'admin/manage-category');
            }
        }
        else
        {
            header('Location:'.SITEURL.'admin/manage-category.php');

        }
?>
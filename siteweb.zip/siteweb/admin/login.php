<?php include('../config/constants.php'); ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="../css/admin.css">

</head>
<body>
    <div class="login">
        <h1 class="text-center">Login</h1>
        <br/><br/>

        <?php 
            if(isset($_SESSION['login'])){
                echo $_SESSION['login'];
                unset($_SESSION['login']);
            }

            if(isset($_SESSION['no-login-message'])){
                echo $_SESSION['no-login-message'];
                unset($_SESSION['no-login-message']);
            }
        ?>
        <br/><br/>
        <!-- Login form starts -->
        <form action="" method="post" class="text-center">
        username: <br/>
        <input type="text" name="username" placeholder="Username"/><br/><br/>
        password: <br/>
        <input type="password" name="password" placeholder="Password"/><br/><br/>

        <input type="submit" name="submit" value="Login" class="btn-primary">
        <br/><br/>
        </form>
         
        <!-- Login form Ends -->


        <p>create by - Chaimae Lamachi</p>
    </div>
</body>
</html>

<?php 
        //check whether the submit buttom is clicked or not
        if(isset($_POST['submit']))
        {
            $username = $_POST['username'];
            $password = md5($_POST['password']);

            //sql 
            $sql = "SELECT * FROM tbl_admin WHERE username = '$username' AND password = '$password'";

            $res = mysqli_query($conn,$sql);

            $count = mysqli_num_rows($res);
             
            if($count == 1){

                $_SESSION['login'] = "<div class='success'> Login Successful.</div>";
                $_SESSION['user'] = $username;//check wherher the user is logged in or not and logged will unset it

                header('Location:'.SITEURL."admin/");

            }else{
                $_SESSION['login'] = "<div class='error text-center'> username or password incorrect.</div>";
                header('Location:'.SITEURL."admin/login.php");

            }

        }
?>
<?php

    //Includ constant  
     include('../config/constants.php'); 


    //1.Destory the session 

    session_destroy();//unst $_SESSION['user']

    //2. Redirect to login page
    header('Location:'.SITEURL.'admin/login.php');
?>
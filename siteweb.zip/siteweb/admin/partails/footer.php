
 <!-- Main content section starts -->
    <div class="footer">
        <div class="wrapper">
            <div class="text-center">2022-All rights reserved</div>
        </div>
    </div>
    <!-- Main content section ends -->
</body>
</html>
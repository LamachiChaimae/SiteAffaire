<?php include 'partails/menu.php'?>

<div class="main-content">
    <div class="wrapper">
        <h1>update Admin</h1>

        <br/><br/>
        <?php 
            //1. Get the id of selected admin 
            $id=$_GET['id'];
            //2.create sql query to get the details 
            $sql="SELECT * FROM tbl_admin where id=$id";
            
            $res=mysqli_query($conn, $sql);
            //Check if the
            if($res==true){
                //check wheter the data is available or not
                $count = mysqli_num_rows($res);

                if($count==1){
                    $row=mysqli_fetch_assoc($res);

                    $full_name = $row['full_name'];
                    $username = $row['username'];

                }else{
                    header("Location:".SITEURL."admin/manage-admin.php");
                }
            }
        
        
        ?>

        <form action="" method="POST">
            <table class="tbl-30">
                <tr>
                        <td>Nom Complet :</td>
                        <td>
                            <input type="text" name="full_name" value="<?php echo $full_name; ?>">
                        </td>
                </tr>
                <tr>
                        <td>Nom d'Utilisateur :</td>
                        <td><input type="text" name="username" value="<?php echo $username; ?>"></td>
                </tr>
                <tr>
                        <td colspan="2">
                            <input type="hidden" name="id" value="<?php echo $id; ?>">
                         <input type="submit" name="submit" value="Update Admin" class="btn-secondry">
                        </td>
                </tr>
            </table>
        </form>
    </div>
</div>

<?php 
    //Check wheter the submit button is clicked or not
    if(isset($_POST['submit'])){
        
        $id = $_POST['id'];
        $full_name = $_POST['full_name'];
        $username = $_POST['username'];

        $sql = "UPDATE tbl_admin SET
        full_name = '$full_name',
        username = '$username'
        where id=$id";

        $res = mysqli_query($conn, $sql);

        if($res == true){
            $_SESSION['update'] = "<div class='success'>Admin updated Successfully .</div>";
            header("Location:".SITEURL."admin/manage-admin.php");
        }else{
            $_SESSION['delete']="<div class='error'> Failed to  delete Admin .</div>";
            header("Location:".SITEURL."admin/manage-admin.php");
    
        }
    }
?>


    <?php include 'partails/footer.php'?>

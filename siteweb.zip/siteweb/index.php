<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/>
    <script src="https://kit.fontawesome.com/51f7ea6787.js" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/c4254e24a8.js" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="css/style.css">
    <title>Document</title>
</head>
<body>
 <?php include 'Header.php'?>
  
      <footer>
        <section>
            <a href="" class="panel">
               <div class="image"> <img src="images/ste1.jpg" alt=""></div>
                <span class="headine">CRÉATION DES ENTREPRISES</span>
                <p>Machrouhi Affaire vous offre le temps suffisant pour vous écouter
                    et vous conseiller sur la forme juridique convenable selon le
                contexte juridique du Maroc</p>
            </a>

            <a href="" class="panel">
            <div class="image"><img src="images/etude.jpg"  alt="" /></div>
            <span class="headine">ETUDE DE MARCHÉ</span>
            <p>A pour but d'analyser l'offre et la demande sur un marché donné
                afin de permettre la mise en place de la stratégie commerciale de
                l'entreprise</p>
            </a>
            <a href="" class="panel">
                <div class="image"> <img src="images/strategie.jpg" alt="" /></div>
                <span class="headine">STRATÉGIE COMMERCIALE</span>
                <p>
                   La stratégie commerciale est la mise en œuvre de moyens marketing
                   et commerciaux coordonnés…
                </p>
            </a>
            <a href="" class="panel">
              <div class="image"> <img src="images/conseilJuridique.jpeg" alt="" /></div>
              <span class="headine">CONSULTATION JURIDIQUE</span>
              <p>
                Nous apportons un conseil ou un aide basé sur l'application d'une
                règle de droit à vos questions pour vous permettre de prendre vos
                décision
              </p>
            </a>
            <a href="" class="panel">
              <div class="image"> <img src="images/formations.jpeg" alt="" /></div>
              <span class="headine">FORMATION</span>
              <p>Ensemble des mesures adoptées en vue de l'acquisition ou du
                  perfectionnement d'une qualification ...
                </p>
            </a>
            <a href="" class="panel">
              <div class="image"><img src="images/accompagnement.jpeg" alt="" /></div>
              <span class="headine">ACCOMPAGNEMENT</span>
              <p>Grâce à notre expérience de plusieurs années, nous avons acquis
                  les meilleures compétences pour vous apporter un conseil de très
                  haute qualité</p>
            </a>
            <a href="" class="panel">
              <div class="image"><img src="images/WhatsApp Image 2021-12-02 at 20.35.38.jpeg" alt="" /></div>
              <span class="headine">DOMICILIATION</span>
              <p>Nous vous permet de domicilier vos entreprises à une adresse
                d’affaire commerciale et connue
              </p>
            </a>
            <a href="" class="panel">
              <div class="image"><img src="images/web.jpg" alt="" /></div>
              <span class="headine">DÉVELOPPEMENT WEB</span>
              <p>Machrouhi Affaire dispose des compétences techniques les plus
                récentes nécessaires pour le développement des plateformes Web et
                Mobile
              </p>
            </a>
            <a href="" class="panel">
              <div class="image"><img src="images/pub.jpeg" alt="" /></div>
              <span class="headine">PUBLICITÉ</span>
              <p>Nous fesons le design, la conception et la réalisation des
                publicité et l’impression des flyers et des cartes visite
              </p>
            </a>
            <a href="" class="panel">
              <div class="image"> <img src="images/appel.jpeg" alt="" /></div>
              <span class="headine">PERMANENCE TÉLÉPHONIQUE</span>
              <p>Quel que soit le domaine d'activité, vos clients vous contactent
                majoritairement par téléphone.
              </p>
            </a>
            <a href="" class="panel">
              <div class="image"><img src="images/bureau.jpg" alt="" /></div>
              <span class="headine">LOCATION DE BUREAU</span>
              <p> Une location temporaire ou en longue durée incluant tout le
                support administratif et logistique nécessaire pour votre
                l’activité</p>
            </a>
            <a href="" class="panel">
              <div class="image"><img src="images/reunion.jpg" alt="" /></div>
              <span class="headine">LOCATION DES SALLES DE RÉUNION</span>
              <p> Le Centre vous fournit une salle de réunion/formation/séminaire
                bien équipée pour tout événement professionnel</p>
            </a>
          </section>


        <h1 class="h1">CRÉER VOTRE SOCIÉTÉ AU MAROC </h1>
        <h3 class="h3">Nous vous fournisson un service complet comprenant</h3>


        <section>
        <a href="" class="panel">
          <div class="image"><i class="fa fa-building" aria-hidden="true"></i></div>
          <span class="headine">Domicilisation</span>
          <p>une adresse prestigieuse pour votre entreprise à partir de 100 TTC DHS/Mois</p>
        </a>
        <a href="" class="panel">
          <div class="image"><i class="fa fa-newspaper-o" aria-hidden="true"></i></div>
          <span class="headine">CRÉATION D'ENTREPRISE</span>
          <p>Création de société SARL,SUARL,SA,...etc <br/> prix 2300 DHS</p>
        </a>
        <a href="" class="panel">
          <div class="image"><i class="fa fa-briefcase" aria-hidden="true"></i></div>
          <span class="headine">COMPTABILITÉ</span>
          <p>DÉCLARATION FISCALE(TVA,CNSS,IR,IS)...<br/>à partir de 100 Dh par Mois</p>
        </a>
        
        <a href="" class="panel">
          <div class="centre">
          <div class="image"><i class="fa fa-bar-chart" aria-hidden="true"></i></div>
          <span class="headine">STRATÉGIE COMMERCIALE</span>
          <p>La strategie commerciale est la mise en oeuvre de moyens markrting et commerciaux <br/>coordonnés qui vont vous permettre de conquérir de nouveaux clients </p>
        </div>
      </a>
      </section>
    </footer>
    <?php include 'Footer.php' ?>
 

    <script src="js/script.js"></script>
</body>
</html>